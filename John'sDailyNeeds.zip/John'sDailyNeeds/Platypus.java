
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Platypus extends Animal implements Walking, Swimming, Abomb
{
    /**
     * Constructor for objects of class phish
     */
    public Platypus()
    {
        this("perpryus The platypus", " He has a PhD in nuclear fysics.");
    }
    
    public Platypus(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "jet A-1 fuel";
    }
    @Override
    public String makeNoise()
    {
        return "rapidly ghghgh angrily";
    }
    @Override
    public String swim()
    {
       return "swish swish!! as the platypus swims you see a bit of code [3-111000]";
    }
    @Override
    public String walk()
    {
       return "flip, flop";
    }
    @Override
    public String abomb()
    {
       return "His fur has become extra long, and has seven eyes";
    }
}
