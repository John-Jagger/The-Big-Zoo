
/**
 * Write a description of class FleshMonster here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FleshMonster extends Animal
implements Walking, Abomb
{
    public FleshMonster() {
        this("the human consuming flesh monster" , "seeing this will begin the process to insanity ");
    }

    public FleshMonster(String name, String description) {
        super(name, description);
    }

    @Override

    public String eat() {
        return("conusmes rotting human corpses");
    }

    @Override
    public String makeNoise() {
        return("gargles burps and demonic screaching, as you list you hear [4-1000101]");
    }

    @Override
    public String walk() {
        return "ooze around";
    }
    
    @Override
    public String abomb() {
        return "has lost all flesh, and with it all meaning to live";
    }
}
