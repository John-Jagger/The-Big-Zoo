public interface Spining
{
    public String spin();
}