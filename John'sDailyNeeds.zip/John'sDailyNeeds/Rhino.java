
/*
 * Rhino extends Animal which means it is inheriting from Animal
 * Animal is the parent, Rhino is the child.
 * Animal is the superclass, Rhino is the subclass.
 * Rhino implements two Interfaces, Walking and Swimming which
 * means that it must override the methods specified by those interfaces
 * ie to implement the Walking interface, Rhino must Override the walk method
 */
public class Rhino extends Animal implements Walking, Abomb
{
    /**
     * Constructor for objects of class Rhino
     */
    public Rhino() 
    {
        /*
         * Call my other constructor that takes two Strings
         * Again, this is called constructor chaining
         */ 
        this("John Snow the Rhino", "I know nothing.");
    }

    /* 
     * This is an overloaded constructor. It has a different method signature
     * Which means the number or types of parameters are different than
     * all other constructors in this class
     */ 
    public Rhino(String name, String description) {
        /* super means call something in my parent (Animal), in this case
         * I am calling the constructor in my parent that takes two parameters
         * and sending in the name and description that were passed into this
         * constructor
         */ 
        super(name, description);
    }

    @Override
    /*
     * Override the eat class from the parent (Animal).
     * This must be done because eat is an abstract method, which requires
     * that it be overloaded by anything that inherits (extends) from Animal
     */
    public String eat() {
        return "Chews on grass";
    }

    @Override
    /*
     * Override the makeNoise class from the parent (Animal).
     * This must be done because eat is an abstract method, which requires
     * that it be overloaded by anything that inherits (extends) from Animal
     */
    public String makeNoise() {
        return "grunt *sniff* grunt";
    }
    
    @Override
    public String walk()
    {
        return "Big Bang sound effect, file missing"; 
    }
    
    @Override
    public String abomb()
    {
        return "The Rhino has sixteen legs and three heads, a sight to behold!!";
        
    }
}
