
/**
 * Abstract class Animal - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Animal
{
    protected String name;
    protected String description;
    
    public static int numAnimals = 0;
    
    public Animal()
    {
        //Call the other constructor that takes one String parameter,
        //passing in none for the name
        //This is called constructer changing when one constructer
        //calls another
        this("none");
    }
    public Animal(String name)
    {
        //call the other constructer that takes 2 strings paremeters,
        //passing in the value referned 
        this(name, "none");
    }
    public Animal(String name, String description)
    {
        this.name = name;
        this.description = description;
        //Increment the numAnimals indicating that another
        // animal has been created 
        numAnimals++;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return this.name;
    }
    public void setDescription(String description)
    {
        this.description = description;
    }
    public String getDescription()
    {
        return this.description;
    }
    @Override
    public String toString()
    {
        return this.name + ": " + this.description;
    }
    
    public abstract String eat();
    
    public abstract String makeNoise();
    
    
}
