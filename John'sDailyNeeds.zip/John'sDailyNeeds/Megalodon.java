
/**
 * Write a description of class Frog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Megalodon extends Animal
    implements Swimming
{
    public Megalodon()
    {
     this("Manny", "I am a big boy fish");   
    }
    
    public Megalodon(String name, String description)
    {
     super(name, description);   
    }
    
    @Override
    
    public String eat()
    {
        return "Bloody mess of other fish";
    }
    
    @Override
    
    public String makeNoise()
    {
      return "*swishh* RAWR *swish swish*";
    }
    
    @Override
    
    public String swim()
    {
        return "WOOOOSH WOOOOSH";
    }
}
