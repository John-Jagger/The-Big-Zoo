
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Droid extends Animal implements Spining, Abomb
{
    /**
     * Constructor for objects of class phish
     */
    public Droid()
    {
        this("IG Model Droid", " He has a PhD in spin, and isn't here. . .");
    }
    
    public Droid(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Is nowhere to be found. . .";
    }
    @Override
    public String makeNoise()
    {
        return ". . .";
    }
    @Override
    public String spin()
    {
       return "I'M Lonely";
    }
    @Override
    public String abomb()
    {
       return "Is nowhere to be found. . .";
    }
}
