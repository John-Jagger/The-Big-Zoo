
/**
 * Write a description of class yoshi here. - Yoshi!!
 *
 * @author John Jagger
 * @version 1.0.1
 */
public class Yoshi extends Animal implements Walking, Abomb
{
    // instance variables - replace the example below with your own
    public Yoshi()
    {
        this("Green Yoshi, of Yoshi tribe","Yooosssshhhhi !!");
    }
    public Yoshi(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Consumes fruits and goomba's";
    }
    @Override
    public String makeNoise()
    {
        return "Blamp Blomp, YOSHI !!";
    }
    @Override
    public String walk()
    {
        return "swick, scwak, Blamp!!";
    }
    @Override
    public String abomb()
    {
        return "Yoishi is now a three story green godzilla, what did you expect, really ??";
    }
}
