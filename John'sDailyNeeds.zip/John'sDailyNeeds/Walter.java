
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Walter extends Animal implements Flying, Abomb
{
    /**
     * Constructor for objects of class phish
     */
    public Walter()
    {
        this("Walter", " He has a PhD in mechanical engineering.");
    }
    
    public Walter(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "aviation biofuel";
    }
    @Override
    public String makeNoise()
    {
        return "metal banging noises";
    }
    @Override
    public String fly()
    {
       return "REEEeEEEEEeEeEEeeEeeEEeeeEEe";
    }
    @Override
    public String abomb()
    {
       return "Walter is now handsome, and is pretty hot, what no, no thats wrong. . . ";
    }
}
