
import java.util.List;
import java.util.ArrayList;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
/**
 * We put a Zoo in your zoo, so you can enjoy your Zoo with some more Zoo for that Zoo action
 *
 * @author Me, John Jagger
 * @version 4.20
 * @Endorse by Connor/and/ Noah 
 */
public class ZooTester
{
    public static void main(String[] args) throws InterruptedException
    {
        System.out.println("");

        List<Animal> animals = new ArrayList<Animal>();
        System.out.println("Welcome to the Animal Zoo!\n");
        System.out.println("We heard you enjoy your zoo's so we puts some zoo's in our zoo for your zoo enjoyment !!"); 
        delayDots(3);
        System.out.println("Please enter all decisions in lower case");
        populateAnimals(animals);
        delayDots(3);
        System.out.println("Make sure to drop by our gift shop !!");
        delayDots(3);

        System.out.println("The Animal Zoo is ready!! We have " + Animal.numAnimals + " animals, knock yourself out. \n");
        health();

        zooBoard(); 
 
        Scanner in = new Scanner(System.in);
        String text = in.nextLine();
        String msg = "";
        while (!text.equals ("leave"))
        {
            switch(text)
            {

                

                
                case "visit animal center":
                animalCenter();
                text = in.nextLine();
                switch(text)
                {
                    case "read sign":
                    msg = signAnimal();
                    text = in.nextLine();

                    default : msg = "You walk away because the sign and building scared you. . .";
                    switch(text)
                    {
                        case "see walking animals":
                        msg = walk(animals);
                        break;

                        case "see swimming animals":
                        msg = swim(animals);
                        break;

                        case "see flying animals":
                        msg = fly(animals);
                        break; 

                        case "extras":
                        System.out.println("You enter the room labled 'EXTRA'");
                        eSign();
                        text = in.nextLine();
                        switch (text)
                        {
                            case "watch them eat":
                            msg = visitLunch(animals);
                            break;

                            case "look at all the animals":
                            msg = visitCages(animals);
                            break;

                            case "listen to sounds":
                            msg = visitSound(animals);
                            break;

                        }
                        break;
                        default : msg = "You decided to leave the animal center because you had no reason to be there.";
                    }
                    break;
                }
                break;

                case "visit gift shop":
                gift();
                System.out.println("WELCOME TO THE Animal Zoo GIFT SHOP, LOOK AT SIGN, PLEASE ");
                text = in.nextLine();
                switch (text)
                {
                    case "look at sign":
                    msg = sign();
                    text = in.nextLine();
                    switch (text)
                    {
                        case "look around back":
                        System.out.println("Holy, you find the famous droid, know for spinning!!");
                        droid1();
                        text = in.nextLine();
                        switch (text)
                        {
                            case "yes":
                            System.out.println("*Megalovania starts playing*");
                            droid2();
                            text = in.nextLine();
                            switch (text)
                            {
                                case "fight":
                                
                                System.out.println("You attack the droid, but you hurt your hand, you deal no damage!!");
                                droid3();
                                System.out.println("The droid attacks you, too much power, you faint. . .");
                                goodNight();
                                break;
                                
                                case "defend":
                                System.out.println("You lay flat on the ground, like a cat? You feel a bit stronger");
                                droid4();
                                System.out.println("The droid completely misses you, weird");
                                droid2();
                                text = in.nextLine();
                                switch (text)
                                {
                                  case "fight":
                                  System.out.println("You attack the droid, you deal 10 damage!!");
                                  droid3();
                                  System.out.println("The droid attacks you, too much power, you faint. . .");
                                  goodNight();
                                  break;
                                  
                                  case "defend":
                                  System.out.println("You lay flat on the ground, like a cat? You feel stronger");
                                  droid4();
                                  System.out.println("The droid completely misses you ,again, weird");
                                  droid2();
                                  text = in.nextLine();
                                  switch (text)
                                  {
                                     case "fight":
                                     System.out.println("You attack the droid, you deal 100 damage!!");
                                     droid3();
                                     System.out.println("The droid attacks you, too much power, you faint. . .");
                                     goodNight();
                                     break; 
                                     
                                     case "defend":
                                     System.out.println("You lay flat on the ground, like a cat? You feel like superman");
                                     droid4();
                                     System.out.println("The droid completely misses you, but he realizes what your doing!!");
                                     droid2();
                                     text = in.nextLine();
                                     switch (text)
                                     {
                                         case "fight":
                                         System.out.println("You attack the droid, you. . .");
                                         boom();
                                         droid5();
                                         System.out.println("The shop owner comes by and says your poor and ask you to leave, you do so");
                                         gameOver();
                                         System.out.println("You should leave the park");
                                         break; 
                                         
                                         case "defend":
                                         System.out.println("You lay flat on the ground, like a cat? You feel like superman");
                                         droid3();
                                         System.out.println("The droid attacks you, too much power, you faint. . .");
                                         goodNight();
                                         break;
                                      }
                                      break;
                                   }
                                   break;
                                }
                                break;
                            }
                            default : msg = "You decided to leave the droid there.";
                            break;
                        }
                        default : msg = "You decided to leave the droid there.";
                        break;
                    }
                    default : msg = "You decided to leave the gift shop because you had no reason to be there.";
                    break;
                }
                break;

                case "visit watch tower":
                wacthTower();
                text = in.nextLine();
                switch (text)
                {
                    case "24 17 56 69 85":
                    System.out.println("You have entered the correct code, the door opens and you climb the tower");
                    System.out.println("There's a button here should I press it? (yes ,or, no)");

                    text = in.nextLine();
                    switch (text)
                    {
                        case "yes":
                        bomb();
                        aBoard();
                        text = in.nextLine();
                        switch (text)
                        {
                            case "visit vince":
                            v2();
                            text = in.nextLine();
                            switch (text)
                            {
                                case "go":
                                msg = abomb(animals);
                                break;
                                default : msg = v();
                            }
                            break;
                            default : msg = v();
                        }
                        break;
                        default : msg = "You get scared and run back to the zoo entrance!!";
                    }
                    break;
                    default : msg = "You don't know the password, so you leave because it made you sad, there must be clues to the right password. . .";
                }
                break;

                case "visit tower again":
                wacthTower2();
                text = in.nextLine();
                switch (text)
                {
                    case "1 2 3 4 5": 
                    System.out.print("You climb the tower find Vince there, you eat the shroom he offers. . .");
                    msg = abomb2(animals);
                    break;
                    default : msg = "You don't know the password, so you leave. . . ";
                }
                break;
                

                
                case "sword please":
                sword();
                System.out.println( "*Bowser 64 theme starts playing*");
                boss1();
                text = in.nextLine();
                switch (text)
                {
                    case "fight":
                    System.out.println("You attack him with your sword, it does five damage, BOOM.");
                    boss2();
                    System.out.println("Oh no the goomba attacks you !!");
                    boss1();
                    text = in.nextLine();
                    switch (text)
                    {
                        case "fight":
                        System.out.println("You attack him with your sword, it does five damage, BOOM.");
                        boss2();
                        System.out.println("Oh no the goomba attacked you !!");
                        System.out.println("You have 0 HP left you faint and are returned to the gate. . .");
                        goodNight();
                        break;

                        case "defend":
                        System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                        boss3();
                        System.out.println("Oh no the goomba attacked you !!");
                        System.out.println("For some reason you feel stronger. . .");
                        boss1();
                        text = in.nextLine();
                        switch (text)
                        {
                            case "fight":
                            System.out.println("You attack him with your sword, it does ten damage, BOOM !!");
                            boss4();
                            System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                            break;

                            case "defend":
                            System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                            boss3();
                            System.out.println("Oh no the goomba attacked you !!");
                            System.out.println("For some reason you feel stronger. . .");
                            boss1();
                            text = in.nextLine();
                            switch (text)
                            {
                                case "fight":
                                System.out.println("You attack him with your sword, it does twenty damage, BOOM !!");
                                boss4();
                                System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                                break;

                                case "defend":
                                System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                                boss3();
                                System.out.println("Oh no the goomba attacked you !!");
                                System.out.println("For some reason you feel really stronger. . .");
                                System.out.println("Come on just fight !!");
                                boss5();
                                text = in.nextLine();
                                switch (text)
                                {
                                    case "fight":
                                    System.out.println("You attack him with your sword, it does one-hundred damage, BOOM !!");
                                    boss4();
                                    System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                                    break;
                                }
                                break;
                            }
                            break;
                        }
                        break;
                    }
                    break;

                    case "defend":
                    System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                    boss3();
                    System.out.println("Oh no the goomba king attacked you !!");
                    System.out.println("For some reason you feel stronger. . .");
                    boss1();
                    text = in.nextLine();
                    switch (text)
                    {
                        case "fight":
                        System.out.println("You attack him with your sword, it does ten damage, BOOM !!");
                        boss2();
                        System.out.println("Oh no the Goomba King attacks you !!");
                        boss1();
                        text = in.nextLine();
                        switch (text)
                        {
                            case "fight":
                            System.out.println("You attack him with your sword, it does five damage, BOOM !!");
                            boss4();
                            System.out.println("You have defeated the Goomba King, but are wounded so you leave to go back to the gate.");
                            break;

                            case "defend":
                            System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                            boss3();
                            System.out.println("Oh no the goomba attacked you !!");
                            System.out.println("For some reason you feel stronger. . .");
                            boss1();
                            text = in.nextLine();
                            switch (text)
                            {
                                case "fight":
                                System.out.println("You attack him with your sword, it does ten damage, BOOM !!");
                                boss4();
                                System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                                break;

                                case "defend":
                                System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                                boss3();
                                System.out.println("Oh no the goomba attacked you !!");
                                System.out.println("For some reason you feel stronger. . .");
                                boss1();
                                text = in.nextLine();
                                switch (text)
                                {
                                    case "fight":
                                    System.out.println("You attack him with your sword, it does twenty damage, BOOM !!");
                                    boss4();
                                    System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                                    break;

                                    case "defend":
                                    System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                                    boss3();
                                    System.out.println("Oh no the goomba attacked you !!");
                                    System.out.println("For some reason you feel really stronger. . .");
                                    System.out.println("Come on just fight !!");
                                    boss5();
                                    text = in.nextLine();
                                    switch (text)
                                    {
                                        case "fight":
                                        System.out.println("You attack him with your sword, it does one-hundred damage, BOOM !!");
                                        boss4();
                                        System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                                        break;
                                    }
                                    break;
                                }
                                break;
                            }
                            break;
                        }
                        case "defend":
                        System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                        boss3();
                        System.out.println("Oh no the goomba attacked you !!");
                        System.out.println("For some reason you feel stronger. . .");
                        boss1();
                        text = in.nextLine();
                        switch (text)
                        {
                            case "fight":
                            System.out.println("You attack him with your sword, it does twenty damage, BOOM !!");
                            boss4();
                            System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                            break;

                            case "defend":
                            System.out.println("You put you arms up like in paper mario (n64) you block in coming damage!!");
                            boss3();
                            System.out.println("Oh no the goomba attacked you !!");
                            System.out.println("For some reason you feel really stronger. . .");
                            System.out.println("Come on just fight !!");
                            boss5();
                            text = in.nextLine();
                            switch (text)
                            {
                                case "fight":
                                System.out.println("You attack him with your sword, it does one-hundred damage, BOOM !!");
                                boss4();
                                System.out.println("You have defeated the Goomba, but are wounded so you leave to go back to the gate.");
                                break;
                            }
                            break;
                        }
                        break;
                    }
                    break;
                }
                break;
                default : msg = "";

                
                

                delayDots(3);
                System.out.println("You are back at the enterance of the zoo, now what?");
                zooBoard();
                text = in.nextLine();
            }
            System.out.println("\n" + msg);
        }
        System.out.println("\n" + "Thank you for coming to the Animal Zoo, Have a great day!!");
        gameOver();
    }

    public static String walk(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("You walk to the 'walking animal' part of the building.");
        delayDots(3);
        System.out.println("You enter a huge room full of different mini biomes with animals in each of them");
        delayDots(3);
        System.out.println("WELCOME TO THE WALKING ANIMALS SECTION, ENJOY !!.");
        delayDots(3);
        System.out.println("");

        for(Animal a : animals)
        {
            if(a instanceof Walking)
            {
                Walking w = (Walking)a;
                msg += a.getName() + ":\n          " + w.walk() + "\n";
            }
        }
        return msg;
    }

    public static String swim(List<Animal> animals) throws InterruptedException
    { 
        String msg = "";
        System.out.println("You walk to the 'swimming animals' part of the building.");
        delayDots(3);
        System.out.println("you enter a huge room full of cubes of water and animals");
        delayDots(3);
        System.out.println("WELCOME TO SWIMMING SECTION, ENJOY !!.");
        delayDots(3);
        System.out.println("");

        for(Animal a : animals)
        {
            if(a instanceof Swimming)
            {
                Swimming s = (Swimming)a;
                msg += a.getName() + ":\n          " + s.swim() + "\n";
            }
        }
        return msg;
    }

    public static String fly(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("You walk to the 'flying animals' part of the building.");
        delayDots(3);
        System.out.println("You enter a very tall room");
        delayDots(3);
        System.out.println("WELCOME TO THE FLYING ANIMAL SECTION, ENJOY !!.");
        delayDots(3);
        System.out.println("");

        for(Animal a : animals)
        {
            if(a instanceof Flying)
            {
                Flying f = (Flying)a;
                msg += a.getName() + ":\n          " + f.fly() + "\n";
            }
        }
        return msg;
    }

    public static String abomb(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("Vince - Alrighty, by the way after seeing this you gonna awake back to the enterance");
        delayDots(3);
        System.out.println("That makes no sense");
        delayDots(3);
        System.out.println("Vince - Hey don't ask me as John!!");
        delayDots(3);
        System.out.println("Vince - Also if you wanna do this again just, visit tower again, and enter, 1 2 3 4 5!!");
        delayDots(3);
        System.out.println("Everything goes black. . .");
        System.out.println("");
        for(Animal a : animals)
        {
            if(a instanceof Abomb)
            {
                Abomb c = (Abomb)a;
                msg += a.getName() + ":\n          " + c.abomb() + "\n";
            }
        }
        return msg;
    }

    public static String abomb2(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("\n" + "Vince - Sup bro, back so soon?");
        delayDots(3);
        System.out.println("Vince - You know you fight that goomba guy, just ask, sword please, and I think they show you to him");
        delayDots(3);
        System.out.println("How do you e-even k-k-n-ow, every thing goes black. . .");
        delayDots(3);
        System.out.println("");
        for(Animal a : animals)
        {
            if(a instanceof Abomb)
            {
                Abomb c = (Abomb)a;
                msg += a.getName() + ":\n          " + c.abomb() + "\n";
            }
        }
        return msg;
    }

    public static String visitCages(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("You decide to see EVERY animal the Animal zoo has");
        delayDots(3);
        System.out.println("You go down some stairs");
        delayDots(3);
        System.out.println("You now can see each animal.");
        delayDots(3);
        System.out.println("");
        for(Animal a : animals)
        {

            msg += a.getName() + ": \n          " + a.getDescription() + "\n";
        }
        return msg;
    }

    public static String visitSound(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("You decide to listen to some animal nosies to relax");
        delayDots(3);
        System.out.println("There is a dark, yet peaceful, room full of headphones");
        delayDots(3);
        System.out.println("You put one on and listen. . .");
        delayDots(3);
        System.out.println("");
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n          " + a.makeNoise() + "\n";
        }
        return msg;
    }

    public static String visitLunch(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("You decide to watch the animals eat lunch");
        delayDots(3);
        System.out.println("As you wacth you are served a free meal");
        delayDots(3);
        System.out.println("It had cheese on it so you throw it away.");
        delayDots(3);
        System.out.println("");
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n          " + a.eat() + "\n";
        }
        return msg;
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i=0; i<dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print("🍄 ");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }

    public static void populateAnimals(List<Animal> animals)
    {
        Shark a1 = new Shark();
        animals.add(a1);

        Yoshi a2 = new Yoshi();
        animals.add(a2);

        Goomba a3 = new Goomba();
        animals.add(a3);

        Thwomp a4 = new Thwomp();
        animals.add(a4);

        Drybone a5 = new Drybone();
        animals.add(a5);

        IronTarkus a6 = new IronTarkus();
        animals.add(a6);

        Bokoblin a7 = new Bokoblin();
        animals.add(a7);

        Rhino a8 = new Rhino();
        animals.add(a8);

        Bigfoot a9 = new Bigfoot();
        animals.add(a9);

        FleshMonster a10 = new FleshMonster();
        animals.add(a10);

        LR57CombatDroid a11 = new LR57CombatDroid();
        animals.add(a11);

        Walter a12 = new Walter();
        animals.add(a12);

        RedPanda a13 = new RedPanda();
        animals.add(a13);

        Droid a14 = new Droid();
        animals.add(a14);

        HammerBro a15 = new HammerBro();
        animals.add(a15);

        Abominablesnowman a16 = new Abominablesnowman();
        animals.add(a16);

        SunBear a17 = new SunBear();
        animals.add(a17);

        Bunny a18 = new Bunny();
        animals.add(a18);

        MourningDove a19 = new MourningDove();
        animals.add(a19);

        Platypus a20 = new Platypus();
        animals.add(a20);

        Lochnessmonster a21 = new Lochnessmonster();
        animals.add(a21);

        GoldFish a22 = new GoldFish();
        animals.add(a22);

        Phish a23 = new Phish();
        animals.add(a23);

        Bella a24 = new Bella();
        animals.add(a24);
    }

    public static void zooBoard()
    {
        System.out.println(" ▄▄▄       ███▄    █  ██▓ ███▄ ▄███▓ ▄▄▄       ██▓       ");
        System.out.println("▒████▄     ██ ▀█   █ ▓██▒▓██▒▀█▀ ██▒▒████▄    ▓██▒       ");
        System.out.println("▒██  ▀█▄  ▓██  ▀█ ██▒▒██▒▓██    ▓██░▒██  ▀█▄  ▒██░       ");
        System.out.println("░██▄▄▄▄██ ▓██▒  ▐▌██▒░██░▒██    ▒██ ░██▄▄▄▄██ ▒██░       ");
        System.out.println(" ▓█   ▓██▒▒██░   ▓██░░██░▒██▒   ░██▒ ▓█   ▓██▒░██████    ");
        System.out.println(" ▒▒   ▓▒█░░ ▒░   ▒ ▒ ░▓  ░ ▒░   ░  ░ ▒▒   ▓▒█░░ ▒░▓      ");
        System.out.println("  ▒   ▒▒ ░░ ░░   ░ ▒░ ▒ ░░  ░      ░  ▒   ▒▒ ░░ ░ ▒      ");
        System.out.println("  ░   ▒      ░   ░ ░  ▒ ░░      ░     ░   ▒     ░ ░      ");
        System.out.println("             ▄▄▄▄▄▄     ▄▄▄▄▄     ▄▄▄▄▄");
        System.out.println("                ▄▄▀     █   █     █   █");
        System.out.println("             ▄▀▀        █   █     █   █");
        System.out.println("             ▀▀▀▀▀▀     ▀▀▀▀▀     ▀▀▀▀▀");
        System.out.println("==========================================================");
        System.out.println("      ⭐ - Here's what you can do and look at - ⭐       ");
        System.out.println("      ⭐ -        visit animal center         - ⭐       ");
        System.out.println("      ⭐ -          visit gift shop           - ⭐       ");
        System.out.println("      ⭐ -         visit watch tower          - ⭐       ");
        System.out.println("");
    }

    public static void aBoard() throws InterruptedException
    {
        System.out.println("When you get to the enterance you faint");
        delayDots(6);
        System.out.println("You awake to a waste land");
        delayDots(3);
        System.out.println("Seems you can do something in the zoo.");
        delayDots(3);
        System.out.println("");
        System.out.println(" ==========███▄====█  ██▓ ███▄ ▄███========================");
        System.out.println("=======    ██ ▀█   █ ▓██▒▓██▒▀█▀ ██▒=======================");
        System.out.println("===  ▀█▄  ▓██  ▀█ ██▒▒██▒▓██    ▓██░▒██  ▀█▄===============  ");
        System.out.println("░██▄▄▄▄██ ▓██▒  ▐▌██▒░██░▒██    ▒██ ░██▄▄▄▄================");
        System.out.println(" ▓█   ▓██▒▒██░   ▓██░░██░▒██▒   ░██▒ ▓█====================");
        System.out.println(" ▒▒   ▓▒█░░ ▒░   ▒ ▒ ░▓  ░ ▒░   ░  ░ ▒▒====================     ");
        System.out.println("  ▒   ▒▒ ░░ ░░   ░ ▒░ ▒ ░░  ░      ░  ▒   ▒▒ ░░ ░ ▒      ");
        System.out.println("  ░   ▒      ░   ░ ░  ▒ ░░      ░     ░   ▒     ░ ░      ");
        System.out.println("             ▄▄▄▄▄▄     ▄▄▄▄▄     ▄▄▄▄▄");
        System.out.println("                ▄▄▀     █   █     █   █");
        System.out.println("=============▄▀▀        █   █     █   █");
        System.out.println("===================     ▀▀▀▀▀     ▀▀▀▀▀");
        System.out.println("==========================================================");
        System.out.println("      ⭐ - He---s wh-t you --n do an---loo--at - ⭐       ");
        System.out.println("        ⭐ -         visit v---e            - ⭐       ");
        System.out.println("        ⭐ -         vis-- vince            - ⭐       ");
        System.out.println("        ⭐ -         vi--- ---ce            - ⭐       ");

    }

    public static String sign()
    {
        System.out.println("==========================================");
        System.out.println("||      Welcome to the Gift Shop        ||");
        System.out.println("||          we are currently            ||");
        System.out.println("||            closed today              ||");
        System.out.println("||        For Technical reason          ||");
        System.out.println("==========================================");
        System.out.println("===You can leave = or = look around back==");
        System.out.println("==========================================");
        return"";
    }

    public static String eSign()
    {
        System.out.println("==========================================");
        System.out.println("||          Welcome to EXTRAS !!        ||");
        System.out.println("||               you can                ||");
        System.out.println("||           listen to sounds           ||");
        System.out.println("||            watch them eat            ||");
        System.out.println("||       look at all the animals        ||");
        System.out.println("==========================================");
        return "";
    }

    public static String food()
    {
        System.out.println("Lol you have no money");
        return "Sorry";
    }

    public static void gift()
    {
        System.out.println(": : : : ::: : : :_________________________: : : : : : : : :|");
        System.out.println(": : : : : :  : _)                         (_ : : : : : : : |");
        System.out.println(": : : : : : : )_ :      Gift Shop        :  _( : : : : : : :|");
        System.out.println(" : : :__________)_________________________(__________  : : |");
        System.out.println(": _ :/ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ\\: _ :|");
        System.out.println(" /_\\ '.Z.'.Z.'.Z.'.Z.'.Z.'.Z.'.Z.'.Z.'.Z.'.Z.'.Z.'.Z.' /_\\ |");
        System.out.println(":=|=: | food * toys      _________     food * toys  | :=|=:|");
        System.out.println(" : : :|   ______    _  .'         '.  _    ______   |: : : |");
        System.out.println("======| .' ,|,  '. /_\\ |           | /_\\ .'  ,|, '. |======|");
        System.out.println("      | | ;;;;;  | =|= |           | =|= |  ;;;;; | |      |");
        System.out.println("      | |_';;;'_n|     |  n______  |     |$_';;;'_| |      |");
        System.out.println("      | |_|-;-|__|     |-|_______|-|     |__|-;-|_| |      |");
        System.out.println("      | |________|     |           |     |________| |      |");
        System.out.println("      |                |           |                |      |");
        System.out.println("______|________________|           |________________|______|");

    }

    public static String boss1() throws InterruptedException
    {
        delayDots(3);
        System.out.println( "                 %%% (((((((((#   ,               ");
        System.out.println( "                   (@&((((((((&&##  @             ");
        System.out.println( "                 (((. &(((##&#%####               ");
        System.out.println( "               ((((    .((,@ ..*####              ");
        System.out.println( "              ((((.  *&#((.@,.,*#####(            ");
        System.out.println( "             (((((((,./((((#,,,*########          ");
        System.out.println( "           (((#(..%%%%%%%%%%%%%% #####%#          ");
        System.out.println( "            (((((###############*/&(#%%#          ");
        System.out.println( "              &%%%%%%%%%%%%%%%%%%%%%%%#           ");
        System.out.println( "               #### #####((((/*(##.               ");
        System.out.println( "             %%%%##%%%#*/(##((/                   ");
        System.out.println( "              ####%&&%%%%%%#(%%%%%                ");
        System.out.println( "                 &%%@&%  @&&###%%%%               ");
        System.out.println( "                             @&&&&                "); 
        System.out.println( "=================================================="); 
        System.out.println( "============== Fight = or = Defend ===============");
        System.out.println( "==================================================");
        return"";
    }

    public static String boss5() throws InterruptedException
    {
        delayDots(3);
        System.out.println( "                 %%% (((((((((#   ,               ");
        System.out.println( "                   (@&((((((((&&##  @             ");
        System.out.println( "                 (((. &(((##&#%####               ");
        System.out.println( "               ((((    .((,@ ..*####              ");
        System.out.println( "              ((((.  *&#((.@,.,*#####(            ");
        System.out.println( "             (((((((,./((((#,,,*########          ");
        System.out.println( "           (((#(..%%%%%%%%%%%%%% #####%#          ");
        System.out.println( "            (((((###############*/&(#%%#          ");
        System.out.println( "              &%%%%%%%%%%%%%%%%%%%%%%%#           ");
        System.out.println( "               #### #####((((/*(##.               ");
        System.out.println( "             %%%%##%%%#*/(##((/                   ");
        System.out.println( "              ####%&&%%%%%%#(%%%%%                ");
        System.out.println( "                 &%%@&%  @&&###%%%%               ");
        System.out.println( "                             @&&&&                "); 
        System.out.println( "=================================================="); 
        System.out.println( "============== Fight = or = Fight ================");
        System.out.println( "==================================================");
        return"";
    }

    public static String boss2() throws InterruptedException
    {
        delayDots(3);
        System.out.println( "                 %%% (((((((((#   ,               ");
        System.out.println( "                   (@&((((((((&&##  @             ");
        System.out.println( "                 (((. &(((##&#%####               ");
        System.out.println( "               ((((    .((,@ ..*####              ");
        System.out.println( "              ((((.  *&#((.@,.,*#####(            ");
        System.out.println( "             (((((((,./((((#,,,*########          ");
        System.out.println( "           (((#(..%%%%%%%%%%%%%% #####%#          ");
        System.out.println( "            (((((###############*/&(#%%#          ");
        System.out.println( "              &%%%%%%%%%%%%%%%%%%%%%%%#           ");
        System.out.println( "               #### #####((((/*(##.               ");
        System.out.println( "             %%%%##%%%#*/(##((/                   ");
        System.out.println( "              ####%&&%%%%%%#(%%%%%                ");
        System.out.println( "                 &%%@&%  @&&###%%%%               ");
        System.out.println( "                             @&&&&                "); 
        System.out.println( "=================================================="); 
        System.out.println( "==============       - 5 HP        ===============");
        System.out.println( "==================================================");
        return"";
    }

    public static String boss3() throws InterruptedException
    {
        delayDots(3);
        System.out.println( "                 %%% (((((((((#   ,               ");
        System.out.println( "                   (@&((((((((&&##  @             ");
        System.out.println( "                 (((. &(((##&#%####               ");
        System.out.println( "               ((((    .((,@ ..*####              ");
        System.out.println( "              ((((.  *&#((.@,.,*#####(            ");
        System.out.println( "             (((((((,./((((#,,,*########          ");
        System.out.println( "           (((#(..%%%%%%%%%%%%%% #####%#          ");
        System.out.println( "            (((((###############*/&(#%%#          ");
        System.out.println( "              &%%%%%%%%%%%%%%%%%%%%%%%#           ");
        System.out.println( "               #### #####((((/*(##.               ");
        System.out.println( "             %%%%##%%%#*/(##((/                   ");
        System.out.println( "              ####%&&%%%%%%#(%%%%%                ");
        System.out.println( "                 &%%@&%  @&&###%%%%               ");
        System.out.println( "                             @&&&&                "); 
        System.out.println( "=================================================="); 
        System.out.println( "==============       - 2 HP        ===============");
        System.out.println( "==================================================");
        return"";
    }

    public static String boss4() throws InterruptedException
    {
        delayDots(3);
        System.out.println( "                 %%% (((((((((#   ,               ");
        System.out.println( "                   (@&((((((((&&##  @             ");
        System.out.println( "                 (((. &(((##&#%####               ");
        System.out.println( "               ((((    .((,@ ..*####              ");
        System.out.println( "              ((((.  *&#((.@,.,*#####(            ");
        System.out.println( "             (((((((,./((((#,,,*########          ");
        System.out.println( "           (((#(..%%%%%%%%%%%%%% #####%#          ");
        System.out.println( "            (((((###############*/&(#%%#          ");
        System.out.println( "              &%%%%%%%%%%%%%%%%%%%%%%%#           ");
        System.out.println( "               #### #####((((/*(##.               ");
        System.out.println( "             %%%%##%%%#*/(##((/                   ");
        System.out.println( "              ####%&&%%%%%%#(%%%%%                ");
        System.out.println( "                 &%%@&%  @&&###%%%%               ");
        System.out.println( "                             @&&&&                "); 
        System.out.println( "=================================================="); 
        System.out.println( "==============   Goomba is Dead    ===============");
        System.out.println( "==================================================");
        System.out.println( "*Bowser 64 theme stops playing*");
        delayDots(3);
        System.out.println(" ▄▄·        ▐ ▄  ▄▄ • ▄▄▄   ▄▄▄· ▄▄▄▄▄▄• ▄▌▄▄▌   ▄▄▄· ▄▄▄▄▄▪         ▐ ▄ .▄▄ · ");
        System.out.println("▐█ ▌▪▪     •█▌▐█▐█ ▀ ▪▀▄ █·▐█ ▀█ •██  █▪██▌██•  ▐█ ▀█ •██  ██ ▪     •█▌▐█▐█ ▀. ");
        System.out.println("██ ▄▄ ▄█▀▄ ▐█▐▐▌▄█ ▀█▄▐▀▀▄ ▄█▀▀█  ▐█.▪█▌▐█▌██▪  ▄█▀▀█  ▐█.▪▐█· ▄█▀▄ ▐█▐▐▌▄▀▀▀█▄");
        System.out.println("▐███▌▐█▌.▐▌██▐█▌▐█▄▪▐█▐█•█▌▐█ ▪▐▌ ▐█▌·▐█▄█▌▐█▌▐▌▐█ ▪▐▌ ▐█▌·▐█▌▐█▌.▐▌██▐█▌▐█▄▪▐█");
        System.out.println("·▀▀▀  ▀█▄▀▪▀▀ █▪·▀▀▀▀ .▀  ▀ ▀  ▀  ▀▀▀  ▀▀▀ .▀▀▀  ▀  ▀  ▀▀▀ ▀▀▀ ▀█▄▀▪▀▀ █▪ ▀▀▀▀ ");
        System.out.println("===============================================================================");
        System.out.println("================You have deafted the mightly, wait what?!======================");
        System.out.println("============You only deafted a fake, wonder how many there are?================");
        System.out.println("===============================================================================");
        return"";
    }

    public static String animalCenter() throws InterruptedException
    {
        System.out.println("You walk to the building called 'Animal Center'.");
        delayDots(3);
        System.out.println("You approach the building");
        delayDots(3);
        System.out.println("You enter the building");
        delayDots(3);
        System.out.println("");
        System.out.println("                                               /\\      /\\");
        System.out.println("                                               ||______||");
        System.out.println("                                               || ^  ^ ||");
        System.out.println("                                               \\| |  | |/");
        System.out.println("                                                |______|");
        System.out.println("              __                                |  __  |");
        System.out.println("             /  \\       ________________________|_/  \\_|");
        System.out.println("            / ^^ \\     /=========================/ ^^ \\===|");
        System.out.println("           /  []  \\   /=====ANIMAL =============/  []  \\==|");
        System.out.println("          /________\\ /==========CENTER=========/________\\=|");
        System.out.println("       *  |        |/==========================|        |=|");
        System.out.println("      *** | ^^  ^^ |---------------------------| ^^  ^^ |--");
        System.out.println("     *****| []  [] |           _____           | []  [] | |");
        System.out.println("    *******        |          /_____\\          |      * | |");
        System.out.println("   *********^^  ^^ |  ^^  ^^  |  |  |  ^^  ^^  |     ***| |");
        System.out.println("  ***********]  [] |  []  []  |  |  |  []  []  | ===***** |");
        System.out.println(" *************     |         @|__|__|@         |/ |*******|");
        System.out.println("***************   ***********--=====--**********| *********");
        System.out.println("***************___*********** |=====| **********|***********");
        System.out.println(" *************     ********* /=======\\ ******** | *********");
        System.out.println("WELCOME THE ANIMAL CENTER PLEASE, READ SIGN, TO SEE WHAT TO DO");
        return"";
    }

    public static void wacthTower() throws InterruptedException
    {
        System.out.println("You walk to an old, and somewhat broken down wacth tower.");
        delayDots(3);
        System.out.println("As you approach the building you notice a weird ringing sound");
        delayDots(3);
        System.out.println("You try to open the door but its locked, and there's a keypad, maybe you know the combo. . .");
        delayDots(3);
        System.out.println("                       ._");
        System.out.println("                       |~");
        System.out.println("                     uuuuu");
        System.out.println("                     |_#-|");
        System.out.println("                     | _#|");
        System.out.println("                     |_ -|");
        System.out.println("________ .$$. ______ | - | _____________");
        System.out.println("        .#$$$. __    |-  | ....__");
        System.out.println("  _.--' $$$$$$    ` -[__N]        `--a:f-");
        System.out.println("        $$$$$$    -.");
        System.out.println("   -.    `:/'    _.))        .--.");
        System.out.println("          ||   .'.-'     _..-.. _.-.");
        System.out.println("=========================================");
        System.out.println("==  enter code [##-##-##-##-##]        ==");
        System.out.println("=========================================");
    }

    public static void wacthTower2() throws InterruptedException
    {
        System.out.println("You walk to wacth tower with the intent to see what ever you saw there again.");
        delayDots(3);
        System.out.println("As you approach the building you notice Vince waving at you");
        delayDots(3);
        System.out.println("You try to open the door with vinces combo, will it work?");
        delayDots(3);
        System.out.println("                       .__--");
        System.out.println("                       |~~");
        System.out.println("                     uuuuu");
        System.out.println("                     |_#-|");
        System.out.println("                     | _#|");
        System.out.println("                     |_ -|");
        System.out.println("________ .$$. ______ | - | _____________");
        System.out.println("        .#$$$. __    |-  | ....__");
        System.out.println("  _.--' $$#$$$    ` -[__N]        `--a:f-");
        System.out.println("        #$$$#$    -.");
        System.out.println("   -.    `:/'    _.))        .--.");
        System.out.println("          ||   .'.-'     _..-.. _.-.");
        System.out.println("=========================================");
        System.out.println("==  enter code [##-##-##-##-##]        ==");
        System.out.println("=========================================");
    }

    public static String goodBye()
    {
        return "for some odd reason after looking at the animals you left the building, odd. . .";
    }

    public static void bomb()
    {
        System.out.println("     _.-^^---....,,--  ");
        System.out.println(" _--                  --_ ");
        System.out.println("<                        >)");
        System.out.println("|                         |");
        System.out.println(" \\._                   _./");
        System.out.println("    ```--. . , ; .--'''");
        System.out.println("          | |   |");
        System.out.println("       .-=||  | |=-.");
        System.out.println("       `-=#$%&%$#=-'");
        System.out.println("          | ;  :|");
        System.out.println("_____.,-#%&$@%#&#~,._____");
        System.out.println("=========================");
        System.out.print("You just shoot off a A-bomb, and rush down back the main entance of the zoo!!");
    }

    public static String signAnimal()
    {
        System.out.println("==========================================");
        System.out.println("||      Welcome to the Animal Center    ||");
        System.out.println("||            you can. . .              ||");
        System.out.println("||          see walking animals         ||");
        System.out.println("||         see swimming animals         ||");
        System.out.println("||           see flying animals         ||");
        System.out.println("||                extras                ||");
        System.out.println("==========================================");
        System.out.println("Remeber that after you see some animals you must leave the building");
        return "";
    }

    public static String v() throws InterruptedException
    {
        System.out.println("You awake in the watch tower to see vince");
        delayDots(3);
        System.out.println("Vince - Yo you been trippen on my shrooms broooo?");
        delayDots(3);
        System.out.println("You notice a shroom in your hand, you just got drugged boi!");
        delayDots(3);
        System.out.println("Vince - Hey, man how was it, did you see Jesus, becuase I'm seeing him right now BRO");
        delayDots(3);
        System.out.println("You - Vince your high, what are you doing here?");
        delayDots(3);
        System.out.println("Vince - I wanted fight some animals");
        delayDots(1);
        System.out.println("You - Animals?");
        delayDots(1);
        System.out.println("Vince - Yep, hey just ask, give me sword, at the gate and they give you one bro. . .");
        delayDots(3);
        System.out.println("You - Vince go home, please");
        return "";
    }

    public static String v2() throws InterruptedException
    {
        delayDots(3);
        System.out.println("You walk around the waste land of a zoo looking for, vince?");
        delayDots(3);
        System.out.println("You goto where the animal center should be, but there's lab, you go inside");
        delayDots(3);
        System.out.println("As you enter you see vince?!");
        delayDots(3);
        System.out.println("Vince - Yo hey bro I didn't know you can to the lab to smoke");
        delayDots(3);
        System.out.println("You look around and realize that you must be dead so you ask Vince if this is hell");
        delayDots(3);
        System.out.println("Vince - Nah bro you just trip'n, hey do you wanna see something crazzzzzy?!");
        delayDots(3);
        System.out.println("You wonder should you keep this up or try to snap out of it, go on? enter, go, to go on");
        return "";
    }

    public static String sword() throws InterruptedException
    {
        delayDots(3);
        System.out.println("You are give a sword out of nowhere, weird. . .");
        delayDots(3);
        System.out.println("Then some gates open some where, so you look for some reason. . .");
        delayDots(3);
        System.out.println("You find the source and its by the animal center, prepare for battle . . .");
        delayDots(3);
        System.out.println("In front of you is the mighty Goomba king prepare for war !!");
        return"";
    }

    public static String goodNight()
    {
        System.out.println(" __    ___   ___   ___       _      _   __    _    _____ ");
        System.out.println("/ /`_ / / \\ / / \\ | | \\     | |\\ | | | / /`_ | |_|  | |  ");
        System.out.println("\\_\\_/ \\_\\_/ \\_\\_/ |_|_/     |_| \\| |_| \\_\\_/ |_| |  |_|  ");
        return"";
    }

    public static String droid1()
    {
        System.out.println("         _____");
        System.out.println("       .'/L|__`.");
        System.out.println("      / =[_]O|` \\");
        System.out.println("      |'+_____':|");
        System.out.println("    __:='|____`-:__");
        System.out.println("   ||[] ||====| []||");
        System.out.println("   ||[] | |=| | []||");
        System.out.println("   |:||_|=|U| |_||:|");
        System.out.println("   |:|||]_=_ =[_||:| ");
        System.out.println("   | |||] [_][]C|| |");
        System.out.println("   | ||-'''''''-|| | ");
        System.out.println("   /|\\_\\_|_|_/_//|\\ ");
        System.out.println("  |___|   /|\\   |___| ");
        System.out.println("  `---'  |___|  `---' ");
        System.out.println("         `---'");
        System.out.println("=======================");
        System.out.println("=======Fight ME========");
        System.out.println("===Fight? - yes or no==");
        System.out.println("=======================");
        return "";
    }
    
    public static String droid2()
    {
        System.out.println("         _____");
        System.out.println("       .'/L|__`.");
        System.out.println("      / =[_]O|` \\");
        System.out.println("      |'+_____':|");
        System.out.println("    __:='|____`-:__");
        System.out.println("   ||[] ||====| []||");
        System.out.println("   ||[] | |=| | []||");
        System.out.println("   |:||_|=|U| |_||:|");
        System.out.println("   |:|||]_=_ =[_||:| ");
        System.out.println("   | |||] [_][]C|| |");
        System.out.println("   | ||-'''''''-|| | ");
        System.out.println("   /|\\_\\_|_|_/_//|\\ ");
        System.out.println("  |___|   /|\\   |___| ");
        System.out.println("  `---'  |___|  `---' ");
        System.out.println("         `---'");
        System.out.println("=======================");
        System.out.println("===Fight======Defend===");
        System.out.println("=======================");
        return "";
    }
    
    public static String droid3() throws InterruptedException
    {
        delayDots(3);
        System.out.println("         _____");
        System.out.println("       .'/L|__`.");
        System.out.println("      / =[_]O|` \\");
        System.out.println("      |'+_____':|");
        System.out.println("    __:='|____`-:__");
        System.out.println("   ||[] ||====| []||");
        System.out.println("   ||[] | |=| | []||");
        System.out.println("   |:||_|=|U| |_||:|");
        System.out.println("   |:|||]_=_ =[_||:| ");
        System.out.println("   | |||] [_][]C|| |");
        System.out.println("   | ||-'''''''-|| | ");
        System.out.println("   /|\\_\\_|_|_/_//|\\ ");
        System.out.println("  |___|   /|\\   |___| ");
        System.out.println("  `---'  |___|  `---' ");
        System.out.println("         `---'");
        System.out.println("=======================");
        System.out.println("== -9999999999999999 ==");
        System.out.println("=======================");
        delayDots(3);
        return "";
    }
    
    public static String droid4() throws InterruptedException
    {
        delayDots(3);
        System.out.println("         _____");
        System.out.println("       .'/L|__`.");
        System.out.println("      / =[_]O|` \\");
        System.out.println("      |'+_____':|");
        System.out.println("    __:='|____`-:__");
        System.out.println("   ||[] ||====| []||");
        System.out.println("   ||[] | |=| | []||");
        System.out.println("   |:||_|=|U| |_||:|");
        System.out.println("   |:|||]_=_ =[_||:| ");
        System.out.println("   | |||] [_][]C|| |");
        System.out.println("   | ||-'''''''-|| | ");
        System.out.println("   /|\\_\\_|_|_/_//|\\ ");
        System.out.println("  |___|   /|\\   |___| ");
        System.out.println("  `---'  |___|  `---' ");
        System.out.println("         `---'");
        System.out.println("=======================");
        System.out.println("========= -0 ==========");
        System.out.println("=======================");
        delayDots(3);
        return "";
    }
    
    public static String droid5() throws InterruptedException
    {
        delayDots(3);
        System.out.println("         _____");
        System.out.println("       .'/L|__`.");
        System.out.println("      / =[_]O|` \\");
        System.out.println("      |'+_____':|");
        System.out.println("    __:='|____`-:__");
        System.out.println("   ||[] ||====| []||");
        System.out.println("   ||[] | |=| | []||");
        System.out.println("   |:||_|=|U| |_||:|");
        System.out.println("   |:|||]_=_ =[_||:| ");
        System.out.println("   | |||] [_][]C|| |");
        System.out.println("   | ||-'''''''-|| | ");
        System.out.println("   /|\\_\\_|_|_/_//|\\ ");
        System.out.println("  |___|   /|\\   |___| ");
        System.out.println("  `---'  |___|  `---' ");
        System.out.println("         `---'");
        System.out.println("=======================");
        System.out.println("=I have lost, how sad==");
        System.out.println("=======================");
        delayDots(3);
        System.out.println("*Megalovania stops playing*");
        System.out.println("The droid tazzs you and steals all your money!!");
        return "";
    }
    
    public static void boom() throws InterruptedException
    {
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println("_________________________");
        System.out.println("=========================");
        delayDots(3);
        System.out.println("     _.-^^---....,,--  ");
        System.out.println(" _--                  --_ ");
        System.out.println("<                        >)");
        System.out.println("|                         |");
        System.out.println(" \\._                   _./");
        System.out.println("    ```--. . , ; .--'''");
        System.out.println("          | |   |");
        System.out.println("       .-=||  | |=-.");
        System.out.println("       `-=#$%&%$#=-'");
        System.out.println("          | ;  :|");
        System.out.println("_____.,-#%&$@%#&#~,._____");
        System.out.println("=========================");
        System.out.print("You attack the droid, and do a billion damage!!");
        delayDots(3);
        
        
    }
    
    public static void health() throws InterruptedException
    {
        System.out.println("REMEMBER YOU HAVE 10 HP, AND EVERY TIME YOU COME TO THE MAIN GATE IT IS FULLY RESTORED");
        System.out.println("                          ......       ......");
        System.out.println("                        .:oOOOOo:.   .:oOOOOo:.");
        System.out.println("                      .:oOO:'':Oo:. .:oO:'':OOo:.");
        System.out.println("                     .:oO:'    ':Oo:oO:'    ':Oo:.");
        System.out.println("                     :oO:        ':O:'        :Oo:");
        System.out.println("                     :oO:          '          :Oo:");
        System.out.println("                     ':oO:                   :Oo:'");
        System.out.println("                      ':oO:                 :Oo:'");
        System.out.println("                       ':oO.             .Oo:'");
        System.out.println("                         ':oO.         .Oo:'");
        System.out.println("                           ':oO.     .Oo:'");
        System.out.println("                             ':oO. .Oo:'");
        System.out.println("                               'oO:Oo'");
        System.out.println("                                'oOo");
        System.out.println("                                 'o'");
        delayDots(3);
        System.out.println("The zoo is all ready for you now!!");
    }
    
    public static void gameOver()
    {
        System.out.println("");
        System.out.println("   ▄██████▄     ▄████████   ▄▄▄▄███▄▄▄▄      ▄████████       ▄██████▄   ▄█    █▄     ▄████████    ▄████████");
        System.out.println("  ███    ███   ███    ███ ▄██▀▀▀███▀▀▀██▄   ███    ███      ███    ███ ███    ███   ███    ███   ███    ███ ");
        System.out.println("  ███    █▀    ███    ███ ███   ███   ███   ███    █▀       ███    ███ ███    ███   ███    █▀    ███    ███ ");
        System.out.println(" ▄███          ███    ███ ███   ███   ███  ▄███▄▄▄          ███    ███ ███    ███  ▄███▄▄▄      ▄███▄▄▄▄██▀ ");
        System.out.println("▀▀███ ████▄  ▀███████████ ███   ███   ███ ▀▀███▀▀▀          ███    ███ ███    ███ ▀▀███▀▀▀     ▀▀███▀▀▀▀▀   ");
        System.out.println("  ███    ███   ███    ███ ███   ███   ███   ███    █▄       ███    ███ ███    ███   ███    █▄  ▀███████████ ");
        System.out.println("  ███    ███   ███    ███ ███   ███   ███   ███    ███      ███    ███ ███    ███   ███    ███   ███    ███ ");
        System.out.println("  ████████▀    ███    █▀   ▀█   ███   █▀    ██████████       ▀██████▀   ▀██████▀    ██████████   ███    ███ ");
        System.out.println("");
    }

}
