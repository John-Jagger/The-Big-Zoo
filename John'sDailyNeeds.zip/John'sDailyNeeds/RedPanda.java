
/**
 * Write a description of class RedPanda here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RedPanda extends Animal implements Abomb
{
    public RedPanda()
    {
        this("Akio", "Loving the Weather");
    }
    
    public RedPanda(String name, String Decription)
    {
        super(name, Decription);
    }
    
    @Override
    
    public String makeNoise()
    {
       return "Squeek";
    }
    
    @Override
    
    public String eat()
    {
       return "Crunch";
    }
    
    @Override
    public String abomb()
    {
       return "Its now black, and has one hundred teeth, spoooky";
    }
}
