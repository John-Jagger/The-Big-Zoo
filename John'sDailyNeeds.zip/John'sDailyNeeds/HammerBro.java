
/**
 * Write a description of class Frog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class HammerBro extends Animal
    implements Walking, Swimming, Abomb
{
    public HammerBro()
    {
     this("Hammer the Bro the hammer bro", "Get recked Mario");   
    }
    
    public HammerBro(String name, String description)
    {
     super(name, description);   
    }
    
    @Override
    
    public String eat()
    {
        return "Eats hammers and pizza";
    }
    
    @Override
    
    public String makeNoise()
    {
      return "Hey Hey";
    }
    
    @Override
    
    public String walk()
    {
        return "bounce, bounce!! as the hammer bro walks you see a bit of code on the bottom of his shoe [2-10001]";
    }
    
    @Override
    
    public String swim()
    {
        return "*drowning*";
    }
    
    @Override
    
    public String abomb()
    {
        return "He is now super thick, heh, thick bro. . .";
    }
}
