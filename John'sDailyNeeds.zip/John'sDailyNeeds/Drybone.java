
/**
 * Write a description of class drybone here. - He sure isn't alive
 *
 * @author John Jagger
 * @version 1.0.1
 */
public class Drybone extends Animal implements Walking, Abomb
{
    // instance variables - replace the example below with your own
    public Drybone()
    {
        this("Dry-ie the Dry Bone", ". . . K I L L . . . M E . . .");
    }
    public Drybone(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Doesn't eat, has no soul";
    }
    @Override
    public String makeNoise()
    {
        return "Kuwank";
    }
    @Override
    public String walk()
    {
        return "Clunk Clank";
    }
    @Override
    public String abomb()
    {
        return "Nothing change, it wants to die";
    }
}
