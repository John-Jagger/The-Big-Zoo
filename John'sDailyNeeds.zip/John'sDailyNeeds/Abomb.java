public interface Abomb
{
    public String abomb();
}
