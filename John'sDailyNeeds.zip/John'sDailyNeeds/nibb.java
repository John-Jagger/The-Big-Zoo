
/**
 * Write a description of class nibb here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class nibb
{
    public static void main(){
        int actual = 5;
        method(actual);
    }
    public static void method(double formal){
        System.out.println(formal);
    }
    
}
